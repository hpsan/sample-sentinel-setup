Microsoft Azure CLI 'sentinel' Extension
==========================================

This package is for the 'sentinel' extension.
i.e. 'az sentinel'

.. :changelog:

Release History
===============

0.1.0
++++++
* Initial release.

